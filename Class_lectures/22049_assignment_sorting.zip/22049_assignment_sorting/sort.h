#ifndef SORT_H
#define SORT_H

#include <iostream>
#include <vector>
#include <functional>

template<typename T>
class Sort {
public:
    static void bubbleSort(std::vector<T>& arr, std::function<bool(const T&, const T&)> compare);
    static void quickSort(std::vector<T>& arr, int left, int right);
    static void mergeSort(std::vector<T>& arr, int left, int right);
	 static void shuffleSort(std::vector<T>& arr, int left, int right);
    // Default constructor
    Sort() {}

    // Constructor to initialize Sort objects with a vector
    Sort(std::vector<T>& arr) : value(arr) {}

private:
    std::vector<T> value;

    static void merge(std::vector<T>& arr, int left, int mid, int right);
    static int partition(std::vector<T>& arr, int left, int right);
};

template<typename T>
void Sort<T>::bubbleSort(std::vector<T>& arr, std::function<bool(const T&, const T&)> compare) {
    int n = arr.size();
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (compare(arr[j], arr[j + 1])) {
                std::swap(arr[j], arr[j + 1]);
            }
        }
    }
}

template<typename T>
void Sort<T>::quickSort(std::vector<T>& arr, int left, int right) {
    if (left < right) {
        int pi = partition(arr, left, right);
        quickSort(arr, left, pi - 1);
        quickSort(arr, pi + 1, right);
    }
}

template<typename T>
int Sort<T>::partition(std::vector<T>& arr, int left, int right) {
    T pivot = arr[right];
    int i = left - 1;
    for (int j = left; j <= right - 1; j++) {
        if (arr[j] < pivot) {
            i++;
            std::swap(arr[i], arr[j]);
        }
    }
    std::swap(arr[i + 1], arr[right]);
    return i + 1;
}

template<typename T>
void Sort<T>::mergeSort(std::vector<T>& arr, int left, int right) {
    if (left < right) {
        int mid = left + (right - left) / 2;
        mergeSort(arr, left, mid);
        mergeSort(arr, mid + 1, right);
        merge(arr, left, mid, right);
    }
}

template<typename T>
void Sort<T>::merge(std::vector<T>& arr, int left, int mid, int right) {
    int n1 = mid - left + 1;
    int n2 = right - mid;
    std::vector<T> L(n1), R(n2);
    for (int i = 0; i < n1; i++) {
        L[i] = arr[left + i];
    }
    for (int j = 0; j < n2; j++) {
        R[j] = arr[mid + 1 + j];
    }
    int i = 0, j = 0, k = left;
    while (i < n1 && j < n2) {
        if (L[i] <= R[j]) {
            arr[k] = L[i];
            i++;
        } else {
            arr[k] = R[j];
            j++;
        }
        k++;
    }
    while (i < n1) {
        arr[k] = L[i];
        i++;
        k++;
    }
    while (j < n2) {
        arr[k] = R[j];
        j++;
        k++;
    }
}
template<typename T>
void Sort<T>::shuffleSort(std::vector<T>& arr, int left, int right) {
    if (left < right) {
        // Shuffle the array
        std::srand(std::time(nullptr));
        for (int i = right; i > left; --i) {
            int j = left + std::rand() % (i - left + 1);
            std::swap(arr[i], arr[j]);
        }

        int mid = left + (right - left) / 2;
        shuffleSort(arr, left, mid);
        shuffleSort(arr, mid + 1, right);
        merge(arr, left, mid, right);
    }
}
#endif // SORT_H
